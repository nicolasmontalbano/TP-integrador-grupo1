history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clearñ hostnameñ ip '4 'o addr show ] cut 'd{ { 'f2,7ñ ip route ] head '3ñ dpkg 'l openssh'server 2:/1 ] tail '1ñ cat -etc-debian?versionñ lsblk 'o NAME,SIZE,FSTYPE,MOUNTPOINT
loadkeys us
clearñ hostnameñ ip '4 'o addr show ] cut 'd{ { 'f2,7ñ ip route ] head '3ñ dpkg 'l openssh'server 2:/1 ] tail '1ñ cat -etc-debian?versionñ lsblk 'o NAME,SIZE,FSTYPE,MOUNTPOINT
clear
dpkg-reconfigure keyboard-configuration 
service keyboard-setup restart
clear
echo T1 T1%/-)=¿_'?¡('+"*.,ñÑ;:]"°
hostnameñ ip '4 'o addr show ] cut 'd{ { 'f2,7ñ ip route ] head '3ñ dpkg 'l openssh'server 2:/1 ] tail '1ñ cat -etc-debian?versionñ lsblk 'o NAME,SIZE,FSTYPE,MOUNTPOINT
clear
echo A1 A1%&/()=?-_+*[]{}.,;:<>
echo A2 \|@~"'
clear
hostname; ip -4 -o addr show | cut -d' ' -f2,7; ip route | head -3; cat /etc/resolv.conf | head -3; dpkg -l openssh-server 2>&1 | tail -1; cat /etc/debian_version; lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT
clear
clear
hostnamectl set-hostname TPServer; sed -i 's/debian/TPServer/g' /etc/hosts; hostname; head -3 /etc/hosts; tail -5 /etc/network/interfaces; date; grep -v '#' /etc/apt/sources.list
apt-get update 2>&1 | tail -8
clear
cp /etc/apt/sources.list /etc/apt/sources.list.orig; echo 'deb http://deb.debian.org/debian bullseye main' > /etc/apt/sources.list; echo 'deb http://deb.debian.org/debian bullseye-updates main' >> /etc/apt/sources.list; echo 'deb http://security.debian.org/debian-security bullseye-security main' >> /etc/apt/sources.list; sed -i 's/TPServer.up/TPServer/' /etc/hosts
apt-get update 2>&1 | tail -8
clear
DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server > /tmp/ssh_install.log 2>&1; echo INSTALL_RC=$?; systemctl is-active ssh
clear; tail -12 /tmp/ssh_install.log
clear; sed -i '/security/d' /etc/apt/sources.list; apt-get update > /dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server > /tmp/ssh_install.log 2>&1; echo INSTALL_RC=$?; systemctl is-active ssh; ss -tln | grep :22
clear
install -d -m 700 /root/.ssh; echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDom0gO3Rr2B2IUlyp3HgGMohZzNFfXxgugYcUrpXjcCQHEJ/xZvmY05MZFF5cN3fXTDYadWNDtIC3IpCHYD9dS3RCVrjztayH5CsdE5oBImrVea85bYspZfKlNZ/328r4uQh/8+LcpqpGDvTlj2f8GnnPhABQq5lwoVZ04D9ZOsbwBQM3wVg9POMZo8WXjtPpYvVxfQb6RZNBZoY17EUF73rWlm63Qz6kI5tq6yMyZyaqZGr7G4x+yAV7N/YWxqmNz+fE4Awv3QNyH6xhKIkRTnajEW68aeQuFX+oY0KBSDhyvYeUZvki2s7jVWNXxMu07xYQv7G7VKL14N9Tl3t0i11tsalhyWxBspyzSQmjgQCrOxvCgNUbsaP5/wHATty64QQHLL+roPHxtds/nJcnwHO5fGm3E6iIG4t3ODUrWfd+FkLmlEhzk8+cm8U1G9x58u/NXH4hI264nWR0k6lrnAfSWzlP38B39uFgrjLqzljA8HmAUOBxYLIHmU6nnfTk= sonda@ttys9-HP-ENVY-Notebook' > /root/.ssh/authorized_keys; chmod 600 /root/.ssh/authorized_keys; echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config; echo 'PubkeyAuthentication yes' >> /etc/ssh/sshd_config; systemctl restart ssh; systemctl is-active ssh; ssh-keygen -lf /root/.ssh/authorized_keys
