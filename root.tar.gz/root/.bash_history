history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnameñ cat -etc-debian?versionñ ip '4 'o addr showñ lsblk 'o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
loadkeys us
hostnameñ cat -etc-debian?versionñ ip '4 'o addr showñ lsblk 'o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
ip addr
apt update
ip route
ping 1.1.1.1
echo nameserver 1.1.1.1 > /etc/resolv.conf
apt update
echo nameserver 192.168.1.1 > /etc/resolv.conf
ping deb.debian.org
apt update
apt install openssh-server
cat /etc/resolv.conf
echo deb httpÑ//deb.debian.org/debian bullseye main > /etc/apt/sources.list
apt update
echo deb http://deb.debian.org/debian bullseye main > /etc/apt/sources.list
apt update
apt install openssh-server
echo PermitRootLogin yes >> /etc/ssh/sshd_config
echo PasswordAuthentication yes >> /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
install -d -m 700 /root/.ssh && printf '%s\n' 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDom0gO3Rr2B2IUlyp3HgGMohZzNFfXxgugYcUrpXjcCQHEJ/xZvmY05MZFF5cN3fXTDYadWNDtIC3IpCHYD9dS3RCVrjztayH5CsdE5oBImrVea85bYspZfKlNZ/328r4uQh/8+LcpqpGDvTlj2f8GnnPhABQq5lwoVZ04D9ZOsbwBQM3wVg9POMZo8WXjtPpYvVxfQb6RZNBZoY17EUF73rWlm63Qz6kI5tq6yMyZyaqZGr7G4x+yAV7N/YWxqmNz+fE4Awv3QNyH6xhKIkRTnajEW68aeQuFX+oY0KBSDhyvYeUZvki2s7jVWNXxMu07xYQv7G7VKL14N9Tl3t0i11tsalhyWxBspyzSQmjgQCrOxvCgNUbsaP5/wHATty64QQHLL+roPHxtds/nJcnwHO5fGm3E6iIG4t3ODUrWfd+FkLmlEhzk8+cm8U1G9x58u/NXH4hI264nWR0k6lrnAfSWzlP38B39uFgrjLqzljA8HmAUOBxYLIHmU6nnfTk= sonda@ttys9-HP-ENVY-Notebook' > /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys && ssh-keygen -lf /root/.ssh/authorized_keys
ls
exit
