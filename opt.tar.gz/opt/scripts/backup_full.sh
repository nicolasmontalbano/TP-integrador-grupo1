#!/bin/bash

set -euo pipefail

show_help() {
    cat <<'EOF'
Uso: backup_full.sh ORIGEN DESTINO

Crea un archivo tar.gz del directorio ORIGEN dentro de DESTINO.
El nombre incluye la fecha en formato YYYYMMDD.

Ejemplos:
  backup_full.sh /var/log /backup_dir
  backup_full.sh /www_dir /backup_dir

Opciones:
  -help, --help, -h   Mostrar esta ayuda.
EOF
}

if [[ ${1:-} == "-help" || ${1:-} == "--help" || ${1:-} == "-h" ]]; then
    show_help
    exit 0
fi

if [[ $# -ne 2 ]]; then
    echo "Error: se requieren los argumentos ORIGEN y DESTINO." >&2
    show_help >&2
    exit 2
fi

origin=$1
destination=$2

if [[ ! -d $origin ]]; then
    echo "Error: el origen no existe o no es un directorio: $origin" >&2
    exit 3
fi

if [[ ! -d $destination ]]; then
    echo "Error: el destino no existe o no es un directorio: $destination" >&2
    exit 4
fi

if ! findmnt -T "$origin" >/dev/null 2>&1; then
    echo "Error: el sistema de archivos del origen no está disponible: $origin" >&2
    exit 5
fi

if ! findmnt -T "$destination" >/dev/null 2>&1; then
    echo "Error: el sistema de archivos del destino no está disponible: $destination" >&2
    exit 6
fi

if [[ ! -w $destination ]]; then
    echo "Error: el destino no permite escritura: $destination" >&2
    exit 7
fi

source_name=$(basename "$origin")
if [[ $origin == "/var/log" ]]; then
    source_name=log
fi

date_stamp=$(date +%Y%m%d)
archive="$destination/${source_name}_bkp_${date_stamp}.tar.gz"

tar -czf "$archive" -C "$(dirname "$origin")" "$(basename "$origin")"

if [[ ! -s $archive ]]; then
    echo "Error: el archivo no fue creado correctamente: $archive" >&2
    exit 8
fi

echo "Backup creado: $archive"
echo "Tamaño: $(du -h "$archive" | awk '{print $1}')"

