#!/bin/bash
# backup_full.sh - Backup comprimido de un directorio con fecha en formato ANSI (YYYYMMDD).
# Uso: backup_full.sh [-help] <origen> [destino]

DEFAULT_DEST="/backup_dir"

uso() {
    cat <<EOF
Uso: $(basename "$0") [-help] <origen> [destino]

Genera <nombre_origen>_bkp_YYYYMMDD.tar.gz con el contenido de <origen>
y lo guarda en <destino>.

Argumentos:
  origen     Directorio a backupear (ej: /var/log, /www_dir)
  destino    Directorio donde se guarda el backup (por defecto: $DEFAULT_DEST)
             Debe ser un sistema de archivos montado (ej: la particion de /backup_dir)

Opciones:
  -help, -h, --help    Muestra esta ayuda

Ejemplos:
  $(basename "$0") /var/log /backup_dir     ->  /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz
  $(basename "$0") /www_dir                 ->  /backup_dir/www_dir_bkp_$(date +%Y%m%d).tar.gz
EOF
}

error() { echo "ERROR: $*" >&2; }

case "$1" in
    -help|-h|--help) uso; exit 0 ;;
esac

if [ $# -lt 1 ] || [ $# -gt 2 ]; then
    error "cantidad de argumentos incorrecta."
    uso >&2
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2:-$DEFAULT_DEST}"
DESTINO="${DESTINO%/}"
[ -z "$ORIGEN" ] && ORIGEN="/"

# Validacion del origen: debe existir y estar disponible (leible y dentro de un FS montado)
if [ ! -d "$ORIGEN" ]; then
    error "el origen '$ORIGEN' no existe o no es un directorio."
    exit 2
fi
if [ ! -r "$ORIGEN" ] || ! findmnt -T "$ORIGEN" > /dev/null 2>&1; then
    error "el sistema de archivos del origen '$ORIGEN' no esta disponible."
    exit 2
fi

# Validacion del destino: debe existir, ser un punto de montaje y ser escribible
if [ ! -d "$DESTINO" ]; then
    error "el destino '$DESTINO' no existe."
    exit 3
fi
if ! mountpoint -q "$DESTINO"; then
    error "el destino '$DESTINO' no es un sistema de archivos montado."
    exit 3
fi
if [ ! -w "$DESTINO" ]; then
    error "no hay permiso de escritura en el destino '$DESTINO'."
    exit 3
fi

NOMBRE="$(basename "$ORIGEN")"
FECHA="$(date +%Y%m%d)"
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "Backup de '$ORIGEN' hacia '$ARCHIVO'..."
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"
RC=$?

# tar devuelve 1 cuando algun archivo cambio durante la lectura (normal en /var/log)
if [ $RC -le 1 ]; then
    [ $RC -eq 1 ] && echo "Aviso: algunos archivos cambiaron durante el backup."
    echo "Backup OK: $ARCHIVO ($(du -h "$ARCHIVO" | cut -f1))"
    exit 0
fi

error "fallo la creacion del backup (codigo $RC)."
rm -f "$ARCHIVO"
exit 4
